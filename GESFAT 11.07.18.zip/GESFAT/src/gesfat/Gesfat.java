package gesfat;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JButton;

/**
 *
 * @author Matteo
 */
public class Gesfat {

public static void main(String[]Args){
    MainFrame mf = new MainFrame();
    mf.setVisible(true);
}

}
