/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gesfat;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

public class Clienti extends JFrame {

    public Clienti(String[] nomiColonne, Object[][] data, String titoloFinestra) {

        JTable table = new JTable(data, nomiColonne);
        table.setFont(new Font("TimesRoman", Font.PLAIN, 20));
        table.getTableHeader().setFont(new Font("TimesRoman", Font.PLAIN, 25));
        table.setRowHeight(30);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        //STAMPA
        
        JButton buttonStampa = new JButton("Stampa🖶");
        buttonStampa.setFont(new Font("TimesRoman", Font.PLAIN, 20));
        buttonStampa.setPreferredSize(new Dimension(10,40));
        ActionListener printAction = new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            try {
              MessageFormat headerFormat = new MessageFormat("Page {0}");
              MessageFormat footerFormat = new MessageFormat("- {0} -");
              table.print(JTable.PrintMode.FIT_WIDTH, headerFormat, footerFormat);
            } catch (PrinterException pe) {
              System.err.println("Error printing: " + pe.getMessage());
            }
          }
        };
        buttonStampa.addActionListener(printAction);
        this.add(buttonStampa, BorderLayout.BEFORE_FIRST_LINE);
        //add the table to the frame
        this.add(new JScrollPane(table));
        this.setTitle(titoloFinestra);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.pack();
        this.setVisible(true);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            }
        });
    }
}
