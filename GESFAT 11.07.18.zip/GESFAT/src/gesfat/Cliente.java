package gesfat;

/**
 *
 * @author matteo */
public class Cliente {
    private String nome;
    private String indirizzo;
    private String partitaIVA;
    private String altro;
    public Cliente(String nome, String indirizzo, String partitaIVA, String altro) {
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.partitaIVA = partitaIVA;
        this.altro = altro;
    }

    public String getNome() {
        return this.nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public String getPartitaIVA() {
        return partitaIVA;
    }

    public String getAltro() {
        return altro;
    }
    
}
